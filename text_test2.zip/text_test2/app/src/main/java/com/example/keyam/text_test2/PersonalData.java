package com.example.keyam.text_test2;

public class PersonalData {

private String member_username;
private String member_content;


public String getMember_username() {
        return member_username;
        }

public String getMember_content() {
        return member_content;
        }


public void setMember_username(String member_username) {
        this.member_username = member_username;
        }

public void setMember_content(String member_content) {
        this.member_content = member_content;
        }
        }